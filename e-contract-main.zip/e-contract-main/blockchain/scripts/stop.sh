


docker-compose -f ../artifacts/channel/create-certificate-with-ca/docker-compose.yaml   down
# --------------------------------------------------------------------------------------------

docker-compose -f ../artifacts/docker-compose.yaml   down
# -----------------------------------------------------------