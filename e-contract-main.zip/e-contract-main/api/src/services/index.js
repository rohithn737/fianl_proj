module.exports.authService = require('./auth.service');
module.exports.tokenService = require('./token.service');
module.exports.userService = require('./user.service');
module.exports.agreementService = require('./agreement.service');
module.exports.qsccService = require('./qscc.service')
